from array import array
